var path = new URL(location.href);
var apiKey = path.searchParams.get("apikey");
var reqdata=[];
var cur = 'https://api.exchangeratesapi.io/latest'
fetch(cur).then(res=>res.json()).then(curval=>{
  $('#cover-spin').show()
    reqdata= Object.keys(curval.rates);
    var catOptions = "";
for ( selectdata in reqdata) {
    catOptions += "<option>" + reqdata[selectdata] + "</option>";
}
document.getElementById("from").innerHTML = catOptions;
document.getElementById("to").innerHTML = catOptions;
 $('#cover-spin').hide()

})
function currencyConveter() {
  document.getElementById('output').innerHTML = "";
  $('#cover-spin').show()
  const amount = document.getElementById('amount').value;
  const from = document.getElementById('from').value;
  const to = document.getElementById('to').value;
  if(!amount){
    $('#cover-spin').hide();
    alert("Please enter minimum amount to convert");
    return
  }
  var query = from + '_' + to;

  const cururl = `https://free.currconv.com/api/v7/convert?q=${query}&compact=ultra&apiKey=${apiKey}`;

  const fetchData = fetch(cururl);
  var resultAmount = 0;
  fetchData.then(res=>res.json()).then(amt=>{
    if(amt.status === 400){
      $('#cover-spin').hide();

      alert(amt.error);
      window.location.href = `home.html`;
    }
    else{
      resultAmount = amount * amt[query];
      document.getElementById('output').innerHTML = `${amount} ${from} = ${resultAmount} ${to}`;
      $('#cover-spin').hide()

    }
  }).catch(err=>{console.log(err)})
}
