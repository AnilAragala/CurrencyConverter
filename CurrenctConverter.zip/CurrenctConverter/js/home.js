
var apikey = '';
function submitApiKey() {
  apikey = document.getElementById('apikey').value;
  sessionStorage.setItem("apikey", apikey);
  if(!apikey){
    alert("Please enter valid API key");
  }
  else {
    // window.location = window.location.href.replace("home","converter");
    window.location.href = `converter.html?apikey=${apikey}`;

  }
}
